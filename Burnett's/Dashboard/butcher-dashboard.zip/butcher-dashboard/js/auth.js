/**
 * ==========================================
 * AUTHENTICATION MODULE
 * ==========================================
 * Handles Supabase auth, session management, and role-based routing.
 */

const Auth = {
    currentUser: null,
    currentProfile: null,

    /**
     * Initialize authentication state
     */
    async init() {
        // Check for existing session
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
            await this.handleSession(session);
        }

        // Listen for auth state changes
        supabase.auth.onAuthStateChange(async (event, session) => {
            if (event === 'SIGNED_IN' && session) {
                await this.handleSession(session);
            } else if (event === 'SIGNED_OUT') {
                this.handleSignOut();
            }
        });
    },

    /**
     * Sign in with email and password
     */
    async signIn(email, password) {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
        });

        if (error) throw error;
        return data;
    },

    /**
     * Sign out the current user
     */
    async signOut() {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
        this.handleSignOut();
    },

    /**
     * Handle successful session
     */
    async handleSession(session) {
        this.currentUser = session.user;
        
        // Fetch user profile with role
        const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();

        if (error) {
            console.error('Error fetching profile:', error);
            // Fallback: use demo data for development
            this.currentProfile = this.getDemoProfile(session.user.email);
        } else {
            this.currentProfile = profile;
        }

        // Show the application
        App.showApp();
    },

    /**
     * Handle sign out
     */
    handleSignOut() {
        this.currentUser = null;
        this.currentProfile = null;
        App.showLogin();
    },

    /**
     * Get user role
     */
    getRole() {
        return this.currentProfile?.role || ROLES.STAFF;
    },

    /**
     * Check if user has specific role
     */
    hasRole(role) {
        return this.getRole() === role;
    },

    /**
     * Check if user can access financial data
     */
    canViewFinancials() {
        const role = this.getRole();
        return role === ROLES.SUPERADMIN || role === ROLES.MANAGER;
    },

    /**
     * Check if user can manage users
     */
    canManageUsers() {
        return this.getRole() === ROLES.SUPERADMIN;
    },

    /**
     * Get demo profile for development/testing
     */
    getDemoProfile(email) {
        const demoProfiles = {
            'admin@burnettsbutcher.com': {
                id: 'demo-admin',
                full_name: 'System Admin',
                email: 'admin@burnettsbutcher.com',
                role: ROLES.SUPERADMIN,
            },
            'shane@burnettsbutcher.com': {
                id: 'demo-manager',
                full_name: 'Shane Burnett',
                email: 'shane@burnettsbutcher.com',
                role: ROLES.MANAGER,
            },
            'staff@burnettsbutcher.com': {
                id: 'demo-staff',
                full_name: 'Mike Johnson',
                email: 'staff@burnettsbutcher.com',
                role: ROLES.STAFF,
            },
        };

        return demoProfiles[email] || demoProfiles['staff@burnettsbutcher.com'];
    },

    /**
     * Demo sign-in (for development without Supabase)
     */
    demoSignIn(email) {
        this.currentUser = { email, id: 'demo-' + Date.now() };
        this.currentProfile = this.getDemoProfile(email);
        App.showApp();
    }
};
